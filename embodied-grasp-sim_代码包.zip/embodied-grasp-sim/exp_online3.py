import numpy as np, pickle, json, time, sys
from multiprocessing import Pool
import sim
from sim import *
from grasp import *
PS, AS = 2.0, np.radians(3)

def calz(p, X):
    lp = np.log(np.clip(p, 1e-3, 1 - 1e-3) / (1 - np.clip(p, 1e-3, 1 - 1e-3)))
    G_ = X[:, -10:]           # geometric prior features
    return np.c_[lp, G_[:, [2, 3, 6, 7, 8]], np.ones(len(p))]

class Cal:
    """online Bayesian-style logistic recalibration with an L2 prior around the identity mapping"""
    def __init__(self):
        self.w0 = np.zeros(7); self.w0[0] = 1.0; self.w = self.w0.copy(); self.Z = []; self.y = []
    def score(self, p, X):
        z = calz(p, X) @ self.w; return 1 / (1 + np.exp(-z))
    def add(self, p, x, y): self.Z.append(calz(np.array([p]), x[None])[0]); self.y.append(y)
    def fit(self, lam=2.0, it=200, lr=0.1):
        Z = np.array(self.Z); y = np.array(self.y); w = self.w.copy()
        for _ in range(it):
            q = 1 / (1 + np.exp(-Z @ w)); g = Z.T @ (q - y) / len(y) + lam / len(y) * (w - self.w0)
            w -= lr * g
        self.w = w

def stream(args):
    seed, arm, n_ep, mu = args
    sim.G['mu'] = mu
    rng = np.random.default_rng(seed)
    model = pickle.load(open('model_main.pkl', 'rb')); model.early_stopping = False
    if getattr(model, 'best_loss_', None) is None: model.best_loss_ = np.inf
    model._optimizer.learning_rate_init = 1e-4
    d = np.load('data_main.npz'); Xo, Yo = d['X'], d['Y']
    cal = Cal(); bX, bY = [], []; rows = []
    for ep in range(n_ep):
        sr = np.random.default_rng(seed + ep)
        S = Scene(sr, int(sr.integers(8, 13)), n_stack=int(sr.integers(0, 2)))
        _, ID = S.topid()
        cand = [i for i in range(len(S.objs)) if not S.above(i) and (ID == i).sum() > 20]
        i = int(sr.choice(cand))
        pr = np.random.default_rng(seed * 7 + ep); er = np.random.default_rng(seed * 13 + ep)
        tabu = []; first = None
        for k in range(3):
            Hn, masks = S.observe(sr)
            if i not in masks: break
            C = candidates(masks[i], pr, 64)
            if tabu:
                C = [g for g in C if all(np.hypot(g[0]-t[0], g[1]-t[1]) > 8 or abs(((g[2]-t[2]+np.pi/2) % np.pi)-np.pi/2) > np.radians(20) for t in tabu)] or C
            X = np.stack([feature(Hn, masks[i], g) for g in C]); p = model.predict(X)
            s = cal.score(p, X) if arm == 'online_cal' else p
            j = int(np.argmax(s))
            g = C[j]
            ok, info = evaluate(S, i, g, er, PS, AS)
            if first is None: first = ok
            if arm == 'online_cal': cal.add(p[j], X[j], float(ok))
            if arm == 'online_net': bX.append(X[j]); bY.append(float(ok))
            if ok: break
            tabu.append(g); S.perturb(i, er, 2.0)
        if first is None: continue
        rows.append(dict(ep=ep, ok=bool(first), within=bool(ok), typ=S.objs[i].typ))
        if (ep + 1) % 20 == 0:
            if arm == 'online_cal': cal.fit()
            if arm == 'online_net':
                Xb = np.array(bX); Yb = np.array(bY, np.float32)
                for _ in range(3):
                    jj = rng.choice(len(Xo), len(Xb), replace=False)
                    XX_ = np.r_[Xb, Xo[jj]]; YY_ = np.r_[Yb, Yo[jj]]; pp = rng.permutation(len(XX_))
                    for s0 in range(0, len(XX_), 128): model.partial_fit(XX_[pp[s0:s0+128]], YY_[pp[s0:s0+128]])
    return dict(seed=seed, arm=arm, mu=mu, rows=rows, w=cal.w.tolist())

if __name__ == '__main__':
    n_ep = int(sys.argv[1]); mu = float(sys.argv[2]); seeds = [int(x) for x in sys.argv[3].split(',')]; out = sys.argv[4]
    arms = sys.argv[5].split(',') if len(sys.argv) > 5 else ['frozen', 'online_cal', 'online_net']
    t0 = time.time()
    with Pool(2) as p: R = p.map(stream, [(s, a, n_ep, mu) for s in seeds for a in arms])
    json.dump(R, open(out, 'w'))
    for a in arms:
        rr = [r for r in R if r['arm'] == a]
        print(a, [round(np.mean([x['ok'] for r in rr for x in r['rows'] if b <= x['ep'] < b + 100]), 3) for b in range(0, n_ep, 100)],
              'all', round(np.mean([x['ok'] for r in rr for x in r['rows']]), 3), 'last200', round(np.mean([x['ok'] for r in rr for x in r['rows'] if x['ep'] >= n_ep - 200]), 3))
    for r in R:
        if r['arm'] == 'online_cal': print('w', np.round(r['w'], 2))
    print(time.time() - t0)
