import numpy as np, copy, time, json
from multiprocessing import Pool
from exp_grasp import *
def job(seed):
    rng=np.random.default_rng(seed); S0=Scene(rng,int(rng.integers(10,15)),n_stack=int(rng.integers(0,3)))
    _,ID=S0.topid(); cand=[i for i in range(len(S0.objs)) if not S0.above(i) and (ID==i).sum()>20]
    rows=[]
    for i in list(rng.choice(cand,min(3,len(cand)),replace=False)):
        r=np.random.default_rng(seed*100+int(i)); Hn,m=S0.observe(r)
        for M in [8,16,32,64,128]:
            t=time.time(); g=pol_learned(Hn,m[i],np.random.default_rng(seed+M),model=MODEL,n=M); dt=time.time()-t
            ok,_=evaluate(S0,int(i),g,np.random.default_rng(seed*7+int(i)),PS,AS); rows.append((M,ok,dt))
    return rows
with Pool(2) as p: R=sum(p.map(job,range(9300,9500)),[])
out={M:(float(np.mean([o for m,o,d in R if m==M])),float(np.median([d for m,o,d in R if m==M])*1000)) for M in [8,16,32,64,128]}
print(out); json.dump(out,open('res_abl.json','w'))
