import json, numpy as np, collections
from sim import TYPES, CN
S={}
R=json.load(open('res_e1.json'))
M=['random','pca','antipodal','learned']
S['e1']={m:dict(n=len([x for x in R if x['meth']==m]),first=np.mean([x['first'] for x in R if x['meth']==m]),
         w2=np.mean([x['within'][1] for x in R if x['meth']==m]),w3=np.mean([x['within'][2] for x in R if x['meth']==m]),
         reasons=collections.Counter(x['reason'] for x in R if x['meth']==m and not x['first']).most_common(),
         bytype={t:np.mean([x['first'] for x in R if x['meth']==m and x['typ']==t]) for t in TYPES},
         stacked=np.mean([x['first'] for x in R if x['meth']==m and x['stacked']]) if any(x['stacked'] for x in R) else None) for m in M}
S['e1_ntype']={t:len([x for x in R if x['meth']=='pca' and x['typ']==t]) for t in TYPES}
R3=json.load(open('res_e3.json'))
S['e3']={m:dict(sig=[np.mean([x['ok'] for x in R3 if x['meth']==m and x['sig']==v and x['ps']==2.0]) for v in [0.5,1,2,3,4]],
                 ps=[np.mean([x['ok'] for x in R3 if x['meth']==m and x['ps']==v and x['sig']==1.0]) for v in [1,2,4,6]]) for m in ['pca','antipodal','learned']}
S['e3_n']=len([x for x in R3 if x['meth']=='pca' and x['sig']==1.0 and x['ps']==2.0])
R2=json.load(open('res_e2.json')); S['e2']={}
for k in R2[0]:
    rr=[r[k] for r in R2]; rem=np.array([x['removed'] for x in rr]); n=np.array([x['n'] for x in rr]); t=np.array([x['tries'] for x in rr])
    S['e2'][k]=dict(clear=(rem/n).mean(),full=(rem==n).mean(),tpo=t.sum()/rem.sum(),n=n.mean())
RP=json.load(open('res_plan.json')); S['plan']={}
for mode in ['naive','openloop','ours']:
    S['plan'][mode]=dict(succ=np.mean([r[mode]['success'] for r in RP]),comp=np.mean([r[mode]['comp'] for r in RP]),act=np.mean([r[mode]['actions'] for r in RP]),
        wrong=np.mean([r[mode]['wrong']>0 for r in RP]),relocs=np.mean([r[mode]['relocs'] for r in RP]),
        succ_dep=np.mean([r[mode]['success'] for r in RP if r['n_dep']>0]),succ_nodep=np.mean([r[mode]['success'] for r in RP if r['n_dep']==0]),
        order_ok=np.mean([r[mode]['order_ok'] for r in RP]))
S['plan_n']=len(RP); S['plan_dep']=int(sum(r['n_dep']>0 for r in RP)); S['plan_parse']=float(np.mean([r['parse_ok'] for r in RP]))
S['plan_goalobj']=float(np.mean([r['n_goal_obj'] for r in RP]))
S['rf']=json.load(open('res_rf.json')); S['abl']=json.load(open('res_abl.json'))
S['train']={k:json.load(open(f'train_{k}.json')) for k in ['main']}
for k in S['train']: S['train'][k]={a:b for a,b in S['train'][k].items() if 'curve' not in a}
def conv(o):
    if isinstance(o,dict): return {str(k):conv(v) for k,v in o.items()}
    if isinstance(o,(list,tuple)): return [conv(v) for v in o]
    if isinstance(o,(np.floating,)): return round(float(o),4)
    if isinstance(o,float): return round(o,4)
    return o
json.dump(conv(S),open('summary.json','w'),ensure_ascii=False,indent=1)
print(json.dumps(conv(S),ensure_ascii=False)[:4000])
