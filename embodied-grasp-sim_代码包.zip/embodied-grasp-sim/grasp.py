import numpy as np, cv2
from sim import *
from sim import _footprint

PW, PH = 48, 24          # patch (pixels) along axis x across
DS = 2                   # downsample factor


def extent(mask, cx, cy, th):
    ys, xs_ = np.nonzero(mask)
    if len(xs_) == 0: return 40.0
    px, py = (xs_ + .5) * RES - cx, (ys + .5) * RES - cy
    a = px * np.cos(th) + py * np.sin(th); b = -px * np.sin(th) + py * np.cos(th)
    sel = np.abs(b) < 5
    if sel.sum() < 2: return 40.0
    return a[sel].max() - a[sel].min()


def opening(mask, cx, cy, th):
    return float(np.clip(extent(mask, cx, cy, th) + 16.0, 24.0, G['max_open']))


def centroid(mask):
    return np.array([XX[mask].mean(), YY[mask].mean()])


def candidates(mask, rng, n=64):
    ys, xs_ = np.nonzero(mask)
    c = centroid(mask)
    P = np.c_[(xs_ + .5) * RES, (ys + .5) * RES]
    d = np.linalg.norm(P - c, axis=1)
    w = np.exp(-d / max(d.mean(), 1)); w /= w.sum()
    idx = rng.choice(len(P), n, p=w)
    out = []
    for k, i in enumerate(idx):
        cx, cy = P[i] + rng.normal(0, 1, 2)
        if k < n // 4: cx, cy = c + rng.normal(0, 2, 2)   # some candidates at the centroid (holes, L shapes)
        th = rng.uniform(0, np.pi)
        out.append((cx, cy, th, opening(mask, cx, cy, th)))
    return out


def feature(Hn, mask, g):
    cx, cy, th, op = g
    ctr = (cx / RES - .5, cy / RES - .5)
    M = cv2.getRotationMatrix2D(ctr, np.degrees(th), 1.0)
    M[0, 2] += PW / 2 - ctr[0]; M[1, 2] += PH / 2 - ctr[1]
    hp = cv2.warpAffine(Hn.astype(np.float32), M, (PW, PH), flags=cv2.INTER_LINEAR, borderValue=0)
    mp = cv2.warpAffine(mask.astype(np.float32), M, (PW, PH), flags=cv2.INTER_LINEAR, borderValue=0)
    zc = np.percentile(hp[PH // 2 - 3:PH // 2 + 3, :][mp[PH // 2 - 3:PH // 2 + 3, :] > .5], 80) if (mp[PH // 2 - 3:PH // 2 + 3, :] > .5).any() else hp[PH // 2, PW // 2]
    rel = np.clip((hp - zc) / 30.0, -1.5, 1.5)
    rel = cv2.resize(rel, (PW // DS, PH // DS), interpolation=cv2.INTER_AREA)
    mp = cv2.resize(mp, (PW // DS, PH // DS), interpolation=cv2.INTER_AREA)
    return np.r_[rel.ravel(), mp.ravel(), op / 80.0, zc / 40.0, geo_feature(Hn, mask, g, zc)].astype(np.float32)


def geo_feature(Hn, mask, g, zc):
    """geometric priors computed from the perceived depth/mask: finger clearance, contact normals, COM offset."""
    cx, cy, th, op = g
    ax = np.array([np.cos(th), np.sin(th)]); perp = np.array([-ax[1], ax[0]])
    z = max(zc - G['depth'], G['min_clear'])
    cl = []
    for sgn in (-1, 1):
        r, c, ins = _footprint(cx, cy, ax, perp, sgn * op / 2)
        h = Hn[r, c][ins]
        cl.append(((h.max() if len(h) else 0) - z) / 20.0)
    zg = max(zc - G['depth'], max(cl) * 20.0 + z + G['min_clear'], G['min_clear'])
    grip = (zc - zg) / 10.0
    mc = mask_contacts(mask, g)
    if mc is None: angs, wd = [90.0, 90.0], op
    else: angs, ss = mc; wd = sum(ss)
    ctr = centroid(mask)
    dcom = abs((ctr[0] - cx) * perp[0] + (ctr[1] - cy) * perp[1])
    return np.array([cl[0], cl[1], max(cl), grip, angs[0] / 90, angs[1] / 90, max(angs) / 90, wd / 80, dcom / 20, float(mc is None)])


# ----------------------------------------------------------------- policies
def pol_random(Hn, mask, rng, **k):
    ys, xs_ = np.nonzero(mask); i = rng.integers(len(xs_))
    return ((xs_[i] + .5) * RES, (ys[i] + .5) * RES, rng.uniform(0, np.pi), 70.0)


def pol_pca(Hn, mask, rng, **k):
    P = np.c_[XX[mask], YY[mask]]; c = P.mean(0)
    w, v = np.linalg.eigh(np.cov((P - c).T)); major = v[:, 1]
    th = np.arctan2(major[1], major[0]) + np.pi / 2
    return (c[0], c[1], th, opening(mask, c[0], c[1], th))


def mask_contacts(mask, g):
    """analytic: contact normals on perceived mask along grasp axis."""
    cx, cy, th, op = g
    ax = np.array([np.cos(th), np.sin(th)])
    sm = cv2.GaussianBlur(mask.astype(np.float32), (5, 5), 1.0)
    gy, gx = np.gradient(sm)
    angs = []; ss = []
    for sgn in (-1, 1):
        hit = None
        for s in np.arange(op / 2, 0, -1.0):
            p = np.array([cx, cy]) + sgn * s * ax
            r, c = int(p[1] / RES), int(p[0] / RES)
            if 0 <= r < N and 0 <= c < N and mask[r, c]: hit = (s, r, c); break
        if hit is None: return None
        s, r, c = hit; nx, ny = -gx[r, c], -gy[r, c]; nn = np.hypot(nx, ny)
        if nn < 1e-6: return None
        close_dir = ax if sgn < 0 else -ax
        angs.append(np.degrees(np.arccos(np.clip(-(nx * close_dir[0] + ny * close_dir[1]) / nn, -1, 1)))); ss.append(s)
    return angs, ss


def pol_antipodal(Hn, mask, rng, n=64, **k):
    c = centroid(mask); best = None
    for g in candidates(mask, rng, n):
        r = mask_contacts(mask, g)
        if r is None: continue
        angs, ss = r
        if max(angs) <= np.degrees(np.arctan(G['mu'])) and sum(ss) <= G['max_open'] - 8:
            d = np.hypot(g[0] - c[0], g[1] - c[1])
            if best is None or d < best[0]: best = (d, g)
    return best[1] if best else pol_pca(Hn, mask, rng)


def pol_learned(Hn, mask, rng, model=None, n=64, tabu=(), return_q=False, **k):
    C = candidates(mask, rng, n)
    if tabu:
        C2 = [g for g in C if all(np.hypot(g[0] - t[0], g[1] - t[1]) > 8 or abs(((g[2] - t[2] + np.pi / 2) % np.pi) - np.pi / 2) > np.radians(20) for t in tabu)]
        C = C2 or C
    X = np.stack([feature(Hn, mask, g) for g in C])
    q = model.predict(X)
    i = int(np.argmax(q))
    return (C[i], float(q[i])) if return_q else C[i]
