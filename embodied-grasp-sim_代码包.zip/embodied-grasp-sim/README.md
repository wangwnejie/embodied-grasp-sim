# 基于具身人工智能的工业机器人自主抓取与任务规划方法（代码与数据）

本仓库为论文《基于具身人工智能的工业机器人自主抓取与任务规划方法研究》（王在成，孙颖）的全部仿真代码、训练好的模型和实验结果，可复现论文中的全部表格与图中数据。

## 1. 环境

- Python ≥ 3.10，依赖见 `requirements.txt`：`pip install -r requirements.txt`
- 全部实验只使用 CPU，不需要 GPU，也不调用任何大语言模型或云端服务。
- 论文实验在 2 核 CPU 上完成；`multiprocessing` 默认开 2 个进程。

## 2. 文件说明

| 文件 | 内容 | 对应论文内容 |
|---|---|---|
| `sim.py` | 二维半工业零件抓取仿真平台：7类零件几何、随机摆放与叠放、深度成像、平行夹爪抓取判定（式（3）） | 第四部分第1节、表1 |
| `perceive.py` | 13维形状—高度特征提取、堆叠关系判断（式（1）） | 第三部分第1节 |
| `grasp.py` | 候选位姿采样、几何先验特征、抓取质量计算（式（2））、对比方法（随机、主轴法、几何对向点法） | 第三部分第2节 |
| `plan.py` | 指令解析词表 `LEX`、句式模板 `TEMPL`、指令解析 `parse` | 第三部分第4节、表4 |
| `gen.py` | 生成抓取质量网络训练数据（标签由仿真自动生成） | 第四部分第1节 |
| `train.py` | 训练抓取质量网络（MLP，256/128 隐藏层） | 第四部分第1节 |
| `exp_grasp.py` | 抓取对比（e1）、场景清理（e2）、鲁棒性（e3） | 表2、表3、图3、图4 |
| `abl.py` | 候选位姿数 M 与决策耗时 | 第四部分第3节 |
| `exp_plan.py` | 零件识别随机森林（rf）、指令任务规划（plan） | 第四部分第1、5节，表5 |
| `exp_online3.py` | 低摩擦条件下的在线校准实验（式（5）、式（6）） | 第四部分第5节末尾 |
| `summ.py` | 汇总全部结果为 `summary.json` | — |
| `fig1_framework.py` / `fig2_scene.py` / `fig34_results.py` | 绘制图1~图4 | 图1~图4 |
| `model_main.pkl` | 训练好的抓取质量网络 | — |
| `rf.pkl` | 训练好的零件识别随机森林 | — |
| `data_tiny.npz` | 训练数据小样本，用于快速检查 | — |
| `res_*.json`、`train_main.json`、`summary.json` | 论文所用的全部实验结果 | — |

## 3. 复现步骤

```bash
python3 gen.py main 800 1000          # 生成训练数据 data_main.npz（123 006 个样本，约145 MB，未随仓库上传）
python3 train.py main                 # 训练抓取质量网络 -> model_main.pkl（2核CPU约84 s）
python3 -W ignore exp_plan.py rf      # 训练零件识别随机森林 -> rf.pkl, res_rf.json
python3 -W ignore exp_grasp.py e1     # 抓取性能对比 -> res_e1.json（表2、图3）
python3 -W ignore exp_grasp.py e3     # 鲁棒性 -> res_e3.json（图4）
python3 -W ignore exp_grasp.py e2     # 场景清理 -> res_e2.json（表3）
python3 -W ignore abl.py              # 候选数与耗时 -> res_abl.json
python3 -W ignore exp_online3.py 400 0.25 40000,41000,42000,43000,44000 res_online3.json   # 在线校准
python3 -W ignore exp_plan.py plan 200   # 指令任务 -> res_plan.json（表5）
python3 summ.py                       # 汇总 -> summary.json
python3 fig34_results.py              # 图3、图4
```

仓库已附带训练好的模型和全部结果文件，可跳过前两步，直接运行后续实验或用结果文件核对论文数字。所有随机过程均使用固定随机种子（训练数据种子 1000~1007，测试场景与任务的种子写在各脚本中）。

## 4. 主要超参数

- 抓取质量网络：输入 588 维（高度图和目标掩码两块 96 mm×48 mm 图块，各降采样为 24×12；加上张开宽度、中心高度和 10 维几何先验特征），两层全连接（256、128 个神经元，ReLU），Adam 优化器，初始学习率 0.001，批大小 256，L2 正则系数 1e-4，以 10% 训练数据为验证集早停（连续 5 轮不改善即停止），共约 18.4 万个参数。
- 零件识别随机森林：300 棵树，叶节点最少样本数 2，其余为 scikit-learn 默认值（基尼系数、每次分裂随机选取 √13 个特征、不限深度）；单标签 7 类分类。
- 抓取：扰动采样 K=8，候选位姿数 M=64（场景清理和任务规划为 32），禁忌半径 8 mm、20°，最多尝试 3 次，依赖规划阈值 τ=0.15。

## 5. 许可

代码采用 MIT 许可。
