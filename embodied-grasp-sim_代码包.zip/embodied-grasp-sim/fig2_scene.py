import sys; sys.path.insert(0,'.')
import numpy as np, pickle, copy, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from sim import *; from grasp import *
plt.rcParams.update({'font.sans-serif':['Noto Sans CJK SC'],'axes.unicode_minus':False,'savefig.dpi':600,'font.size':7.5})
CM=1/2.54
M=pickle.load(open('model_main.pkl','rb'))
seed=int(sys.argv[1]) if len(sys.argv)>1 else 9012
rng=np.random.default_rng(seed); S=Scene(rng,13,n_stack=2); H=S.height(); Hn,masks=S.observe(rng)
fig,axs=plt.subplots(1,2,figsize=(15.5*CM,7.3*CM),gridspec_kw=dict(wspace=0.08))
ext=[0,N*RES,N*RES,0]
for a in axs:
    a.imshow(Hn,cmap='Greys',vmin=-2,vmax=18,extent=ext); a.set_xlim(0,N*RES); a.set_ylim(N*RES,0); a.set_xticks([0,100,200,300]); a.set_yticks([0,100,200,300])
    a.set_xlabel('x/mm')
axs[0].set_ylabel('y/mm')
for i,o in enumerate(S.objs):
    if i in masks:
        c=centroid(masks[i]); axs[0].text(c[0],c[1],CN[o.typ]+('*' if o.base>0 else ''),fontsize=5.4,ha='center',va='center',color='black',
            bbox=dict(boxstyle='round,pad=0.12',fc='white',ec='none',alpha=0.8))
def rect(a,g,ok,ls):
    cx,cy,th,op=g; ax_=np.array([np.cos(th),np.sin(th)]); pp=np.array([-ax_[1],ax_[0]])
    for sgn in (-1,1):
        c=np.array([cx,cy])+sgn*op/2*ax_
        P=[c+dx*ax_+dy*pp for dx,dy in [(-3,-5),(3,-5),(3,5),(-3,5)]]
        a.add_patch(Polygon(P,closed=True,fc='white' if ok else 'black',ec='black',lw=0.6,ls=ls))
    a.plot([cx-op/2*ax_[0],cx+op/2*ax_[0]],[cy-op/2*ax_[1],cy+op/2*ax_[1]],color='black',lw=0.6,ls=ls)
stat={'pca':[0,0],'learned':[0,0]}
for i in masks:
    if S.above(i) or masks[i].sum()<20: continue
    r=np.random.default_rng(seed*100+i)
    for meth,ls in [('pca','--'),('learned','-')]:
        g=pol_pca(Hn,masks[i],r) if meth=='pca' else pol_learned(Hn,masks[i],r,model=M)
        ok,_=evaluate(S,i,g,np.random.default_rng(seed*31+i),2.0,np.radians(3),H); stat[meth][0]+=ok; stat[meth][1]+=1
        if meth=='learned': rect(axs[1],g,ok,'-')
        else: rect(axs[1],g,ok,'--')
axs[0].set_title('（a）仿真场景高度图（*为叠放零件）',fontsize=8,y=-0.30)
axs[1].set_title('（b）主轴法（虚线）与本文方法（实线）的抓取位姿',fontsize=8,y=-0.30)
axs[1].set_yticklabels([])
print(stat)
plt.savefig('h2.png',bbox_inches='tight',pad_inches=0.03)
