import numpy as np, pickle, json, copy, time, sys, collections
from multiprocessing import Pool
from scipy import ndimage
from sklearn.ensemble import RandomForestClassifier
from sim import *
from grasp import *
from perceive import shape_feat, infer_support
from plan import parse, make_instruction, LEX

MODEL = pickle.load(open('model_main.pkl', 'rb'))
PS, AS = 2.0, np.radians(3)
TAU = 0.15


# --------------------------------------------------------------- part recognition
def collect(seed0, n):
    X, Y, V = [], [], []
    for s in range(seed0, seed0 + n):
        rng = np.random.default_rng(s); S = Scene(rng, int(rng.integers(8, 13)), n_stack=int(rng.integers(0, 4)))
        Hn, masks = S.observe(rng)
        for i, m in masks.items():
            f = shape_feat(Hn, m)
            if f is None: continue
            X.append(f); Y.append(TYPES.index(S.objs[i].typ)); V.append(m.sum() / max(S.objs[i].M.sum(), 1))
    return np.array(X), np.array(Y), np.array(V)


def train_rf():
    X, Y, V = collect(20000, 500)
    rf = RandomForestClassifier(300, min_samples_leaf=2, random_state=0, n_jobs=2).fit(X, Y)
    Xt, Yt, Vt = collect(21000, 200)
    p = rf.predict(Xt)
    occ = Vt < 0.9
    res = dict(n_train=len(Y), n_test=len(Yt), acc=float((p == Yt).mean()), acc_full=float((p == Yt)[~occ].mean()),
               acc_occ=float((p == Yt)[occ].mean()), n_occ=int(occ.sum()),
               per_type={TYPES[k]: float((p == Yt)[Yt == k].mean()) for k in range(len(TYPES))},
               cm=[[int(((Yt == a) & (p == b)).sum()) for b in range(len(TYPES))] for a in range(len(TYPES))])
    pickle.dump(rf, open('rf.pkl', 'wb')); json.dump(res, open('res_rf.json', 'w'))
    print(json.dumps({k: v for k, v in res.items() if k != 'cm'}))
    return rf


# --------------------------------------------------------------- environment helpers
def relocate(S, j, rng):
    o = S.objs[j]
    H = S.height(exclude=j); occ = ndimage.binary_dilation(H > 0.5, iterations=6)
    for _ in range(200):
        o2 = copy.copy(o); o2.cx, o2.cy = rng.uniform(30, N * RES - 30, 2); o2.th = rng.uniform(0, np.pi); o2.raster()
        if not (o2.M & occ).any():
            o.cx, o.cy, o.th = o2.cx, o2.cy, o2.th; o.raster(); o.base = 0.0
            return True
    return False


def do_grasp(S, i, g, rng, bins, b, log):
    """execute grasp on i; returns ok. consequences of failure (wrong object picked) applied."""
    ok, info = evaluate(S, i, g, rng, PS, AS)
    log['actions'] += 1; log.setdefault('trace', []).append(('pick', S.objs[i].typ, i, ok, info['reason']))
    if ok:
        bins.append((S.objs[i].typ, b, log['clause'])); S.remove(i, rng)
    else:
        r = info['reason']
        if r == 'wrong' and info.get('ids') and info['ids'][0] == info['ids'][1] and info['ids'][0] >= 0 and b is not None:
            k = info['ids'][0]
            if not S.above(k):                                  # gripper actually lifted another part and drops it in the bin
                bins.append((S.objs[k].typ, b, log['clause'])); S.remove(k, rng); log['wrong'] += 1
        elif r == 'covered':
            for j in S.above(i): S.perturb(j, rng, 4.0)
        else:
            S.perturb(i, rng, 2.0)
    return ok


def remaining(goal, placed, S0types):
    t, q, b = goal
    need = S0types.count(t) if q == 'all' else q
    return need - sum(1 for (tt, bb, c) in placed if tt == t and bb == b)


# --------------------------------------------------------------- planners
def run(S, goals, mode, rng, rf):
    types0 = [o.typ for o in S.objs]
    bins = []; log = dict(actions=0, wrong=0, clause=0, relocs=0)
    nobj_goal = sum((types0.count(t) if q == 'all' else min(q, types0.count(t))) for t, q, b in goals)
    budget = 3 * nobj_goal + 8
    if mode == 'openloop':
        Hn, masks = S.observe(rng)
        pred = {i: TYPES[int(rf.predict(shape_feat(Hn, m)[None])[0])] for i, m in masks.items() if shape_feat(Hn, m) is not None}
        on = infer_support(Hn, masks)
        seq = []
        for ci, (t, q, b) in enumerate(goals):
            objs = [i for i in pred if pred[i] == t]
            if q != 'all': objs = objs[:q]
            for i in objs:
                for j, k in on.items():
                    if k == i: seq.append(('reloc', j, None, ci, masks[j]))
                seq.append(('pick', i, b, ci, masks[i]))
        for act, i, b, ci, m in seq:
            if log['actions'] >= budget: break
            log['clause'] = ci
            if not S.alive[i]: continue
            g = pol_learned(Hn, m, rng, model=MODEL)
            if act == 'reloc':
                ok, info = evaluate(S, i, g, rng, PS, AS); log['actions'] += 1; log['relocs'] += 1
                if ok: relocate(S, i, rng)
            else:
                do_grasp(S, i, g, rng, bins, b, log)
        return bins, log
    # closed-loop modes: 'naive' (instruction order, no reasoning) and 'ours'
    for ci, goal in enumerate(goals):
        log['clause'] = ci; t, q, b = goal
        fail_cnt = collections.Counter(); skip = set()
        while remaining(goal, bins, types0) > 0 and log['actions'] < budget:
            Hn, masks = S.observe(rng)
            masks = {i: m for i, m in masks.items() if m.sum() > 15}
            pred = {}
            for i, m in masks.items():
                f = shape_feat(Hn, m)
                if f is not None: pred[i] = TYPES[int(rf.predict(f[None])[0])]
            cand = [i for i in masks if pred.get(i) == t and i not in skip]
            if not cand: break
            if mode == 'naive':
                i = cand[0]; g = pol_learned(Hn, masks[i], rng, model=MODEL, n=32)
                ok = do_grasp(S, i, g, rng, bins, b, log)
                if not ok:
                    fail_cnt[i] += 1
                    if fail_cnt[i] >= 3: skip.add(i)
                continue
            # ours: dependency- and feasibility-aware selection
            on = infer_support(Hn, masks)
            blocked = {k for k in on.values()}
            free = [i for i in cand if i not in blocked]
            if not free:
                i = cand[0]; tops = [j for j, k in on.items() if k == i]
                j = tops[0]; g = pol_learned(Hn, masks[j], rng, model=MODEL)
                ok, info = evaluate(S, j, g, rng, PS, AS); log['actions'] += 1; log['relocs'] += 1
                log.setdefault('trace', []).append(('unstack', S.objs[j].typ, j, ok, info['reason']))
                if ok:
                    # if the top part is itself a goal of the current clause put it in the bin, else move to buffer area
                    if S.objs[j].typ == t and pred.get(j) == t: bins.append((S.objs[j].typ, b, ci)); S.remove(j, rng)
                    else: relocate(S, j, rng)
                else: S.perturb(j, rng, 2.0)
                continue
            scored = [(pol_learned(Hn, masks[i], rng, model=MODEL, n=32, return_q=True), i) for i in free]
            (g, q), i = max(scored, key=lambda x: x[0][1])
            if q < TAU:
                # crowded: relocate the neighbour that is easiest to grasp
                near = [k for k in masks if k != i and (ndimage.binary_dilation(masks[i], iterations=6) & masks[k]).any() and k not in blocked]
                if near:
                    sc = [(pol_learned(Hn, masks[k], rng, model=MODEL, n=32, return_q=True), k) for k in near]
                    (g2, q2), k = max(sc, key=lambda x: x[0][1])
                    ok, info = evaluate(S, k, g2, rng, PS, AS); log['actions'] += 1; log['relocs'] += 1
                    log.setdefault('trace', []).append(('declutter', S.objs[k].typ, k, ok, info['reason'], round(q, 2)))
                    if ok:
                        if S.objs[k].typ == t and pred.get(k) == t: bins.append((S.objs[k].typ, b, ci)); S.remove(k, rng)
                        else: relocate(S, k, rng)
                    else: S.perturb(k, rng, 2.0)
                    continue
            ok = do_grasp(S, i, g, rng, bins, b, log)
            if not ok:
                fail_cnt[i] += 1
                if fail_cnt[i] >= 3: skip.add(i)
    return bins, log


def judge(goals, bins, types0):
    okc = []
    for ci, (t, q, b) in enumerate(goals):
        need = types0.count(t) if q == 'all' else q
        got = sum(1 for (tt, bb, c) in bins if tt == t and bb == b)
        okc.append(got >= need)
    wrong = sum(1 for (tt, bb, c) in bins if not any(tt == t and bb == b for t, q, b in goals))
    # order: clause index recorded must be non-decreasing w.r.t. goal clause of the part
    order_ok = True
    for (tt, bb, c) in bins:
        gi = [k for k, (t, q, b) in enumerate(goals) if t == tt and b == bb]
        if gi and gi[0] != c: order_ok = False
    comp = np.mean(okc)
    return dict(success=bool(all(okc) and wrong == 0 and order_ok), comp=float(comp), wrong=int(wrong), order_ok=order_ok)


def episode(seed):
    rf = pickle.load(open('rf.pkl', 'rb'))
    rng = np.random.default_rng(seed)
    S0 = Scene(rng, 10, n_stack=3)
    types0 = [o.typ for o in S0.objs]
    # goal types: prefer types of supporting parts (dependency) and of parts lying on them
    sup = [S0.objs[i].typ for i in range(len(S0.objs)) if S0.above(i)]
    avail = sorted(set(types0))
    k = 2 if rng.random() < .6 else 3; k = min(k, len(avail))
    first = [sup[rng.integers(len(sup))]] if sup and rng.random() < .8 else []
    rest = [t for t in avail if t not in first]
    ts = first + list(rng.choice(rest, k - len(first), replace=False))
    goals = []
    for bi, t in enumerate(ts, 1):
        cnt = types0.count(t)
        q = 'all' if cnt <= 2 and rng.random() < .6 else int(rng.integers(1, min(cnt, 2) + 1))
        goals.append((t, q, bi))
    text = make_instruction(rng, goals); parsed = parse(text)
    out = dict(seed=seed, text=text, parse_ok=parsed == goals, n_goal_obj=sum(types0.count(t) if q == 'all' else q for t, q, b in goals),
               n_dep=sum(1 for t, q, b in goals for i in range(len(S0.objs)) if S0.objs[i].typ == t and S0.above(i)))
    for mode in ['naive', 'openloop', 'ours']:
        S = copy.deepcopy(S0); r = np.random.default_rng(seed + 11)
        bins, log = run(S, parsed, mode, r, rf)
        out[mode] = dict(**judge(goals, bins, types0), actions=log['actions'], relocs=log['relocs'])
    return out


if __name__ == '__main__':
    if sys.argv[1] == 'rf': train_rf()
    else:
        t0 = time.time()
        with Pool(2) as p: R = p.map(episode, range(30000, 30000 + int(sys.argv[2])))
        json.dump(R, open('res_plan.json', 'w'))
        for mode in ['naive', 'openloop', 'ours']:
            print(mode, 'succ', np.mean([r[mode]['success'] for r in R]), 'comp', np.mean([r[mode]['comp'] for r in R]),
                  'act', np.mean([r[mode]['actions'] for r in R]), 'wrong', np.mean([r[mode]['wrong'] > 0 for r in R]))
        print('parse', np.mean([r['parse_ok'] for r in R]), 'dep', np.mean([r['n_dep'] > 0 for r in R]), time.time() - t0)
