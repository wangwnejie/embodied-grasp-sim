"""perception: part recognition from depth + mask, and support (stacking) relation inference."""
import numpy as np
from scipy import ndimage
from skimage.measure import regionprops, label
from sim import *


def shape_feat(Hn, m):
    m = m.astype(bool)
    if m.sum() < 5: return None
    rp = regionprops(m.astype(np.uint8))[0]
    h = Hn[m]
    ring = ndimage.binary_dilation(m, iterations=3) & ~m
    hr = np.median(Hn[ring]) if ring.any() else 0.0
    holes = ndimage.binary_fill_holes(m) & ~m
    return np.array([m.sum() * RES * RES / 1000, rp.perimeter * RES / 100, rp.euler_number, holes.sum() * RES * RES / 100,
                     rp.solidity, rp.eccentricity, rp.extent, rp.major_axis_length * RES / 50, rp.minor_axis_length * RES / 50,
                     np.percentile(h, 95) - hr, np.std(h), (np.percentile(h, 95) - np.percentile(h, 20)), hr], np.float32)


def infer_support(Hn, masks):
    """returns dict j -> i meaning object j rests on object i (perceived)."""
    on = {}
    for j, mj in masks.items():
        ring = ndimage.binary_dilation(mj, iterations=3) & ~mj
        if ring.sum() == 0: continue
        best = None
        for i, mi in masks.items():
            if i == j: continue
            fr = (ring & mi).sum() / ring.sum()
            if fr >= 0.3:
                hi = np.median(Hn[ring & mi]); hj = np.median(Hn[mj])
                if hi > 2.0 and hj > hi + 1.0 and (best is None or fr > best[0]): best = (fr, i)
        if best: on[j] = best[1]
    return on
