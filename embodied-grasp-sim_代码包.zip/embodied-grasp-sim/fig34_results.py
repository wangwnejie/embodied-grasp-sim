import json, numpy as np, matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
plt.rcParams.update({'font.sans-serif':['Noto Sans CJK SC'],'axes.unicode_minus':False,'savefig.dpi':600,'font.size':7.5,'axes.linewidth':0.8})
CM=1/2.54; K='black'
S=json.load(open('summary.json'))
TY=['nut','bearing','gear','block','bracket','bolt','shaft']; CNs=['螺母','轴承','齿轮','方块','L形支架','螺栓','轴']
M=[('random','随机抓取','white','////'),('pca','主轴法','#bdbdbd',''),('antipodal','几何对向点法','white','....'),('learned','本文方法','#404040','')]
fig,ax=plt.subplots(1,2,figsize=(15.5*CM,5.6*CM),gridspec_kw=dict(width_ratios=[1.75,1],wspace=0.28))
a=ax[0]; w=0.2; x=np.arange(len(TY))
for k,(m,lab,fc,h) in enumerate(M):
    a.bar(x+(k-1.5)*w,[S['e1'][m]['bytype'][t]*100 for t in TY],w,color=fc,edgecolor=K,lw=0.5,hatch=h,label=lab)
a.set_xticks(x); a.set_xticklabels(CNs); a.set_ylabel('首次抓取成功率/%'); a.set_ylim(0,100)
a.legend(ncol=4,frameon=False,fontsize=6.6,loc='upper center',bbox_to_anchor=(0.5,1.16),handlelength=1.4,columnspacing=0.8)
a.set_title('（a）各类零件首次抓取成功率',fontsize=8,y=-0.38)
b=ax[1]; mk={'random':('^',':'),'pca':('s','--'),'antipodal':('o','-.'),'learned':('D','-')}
for m,lab,fc,h in M:
    v=[S['e1'][m]['first'],S['e1'][m]['w2'],S['e1'][m]['w3']]
    b.plot([1,2,3],np.array(v)*100,marker=mk[m][0],ls=mk[m][1],color=K,mfc='white' if m!='learned' else K,ms=4,lw=1,label=lab)
b.set_xticks([1,2,3]); b.set_xlabel('最多尝试次数'); b.set_ylabel('累计抓取成功率/%'); b.set_ylim(30,100)
b.set_title('（b）闭环重抓的累计成功率',fontsize=8,y=-0.38)
for s in ['top','right']: [z.spines[s].set_visible(False) for z in ax]
plt.savefig('h3.png',bbox_inches='tight',pad_inches=0.03)
# fig 4 robustness
fig,ax=plt.subplots(1,2,figsize=(15.5*CM,5.0*CM),gridspec_kw=dict(wspace=0.3))
for m,lab,fc,h in M[1:]:
    ax[0].plot([0.5,1,2,3,4],np.array(S['e3'][m]['sig'])*100,marker=mk[m][0],ls=mk[m][1],color=K,mfc='white' if m!='learned' else K,ms=4,lw=1,label=lab)
    ax[1].plot([1,2,4,6],np.array(S['e3'][m]['ps'])*100,marker=mk[m][0],ls=mk[m][1],color=K,mfc='white' if m!='learned' else K,ms=4,lw=1,label=lab)
ax[0].set_xlabel('深度噪声标准差/mm'); ax[1].set_xlabel('定位误差标准差/mm')
for z in ax: z.set_ylabel('首次抓取成功率/%'); z.set_ylim(20,100); z.spines['top'].set_visible(False); z.spines['right'].set_visible(False)
ax[0].legend(frameon=False,fontsize=6.6,loc='lower left'); 
ax[0].set_title('（a）深度噪声的影响',fontsize=8,y=-0.46); ax[1].set_title('（b）定位误差的影响',fontsize=8,y=-0.46)
plt.savefig('h4.png',bbox_inches='tight',pad_inches=0.03); print('ok')
