"""generate training data: features from noisy observation, label = robust grasp quality from simulator."""
import numpy as np, sys
from multiprocessing import Pool
from sim import *
from grasp import *

def work(args):
    seed, n_scene, types = args
    rng = np.random.default_rng(seed); X = []; Y = []; T = []
    for k in range(n_scene):
        S = Scene(rng, int(rng.integers(8, 15)), types=types, n_stack=int(rng.integers(0, 4)))
        H = S.height(); Hn, masks = S.observe(rng, sig=rng.uniform(0.5, 2.0))
        for i, m in masks.items():
            if m.sum() < 15: continue
            C = candidates(m, rng, 12)
            C.append(pol_pca(Hn, m, rng))
            for g in C:
                X.append(feature(Hn, m, g)); Y.append(robust_quality(S, i, g, rng, 8, H=H)); T.append(TYPES.index(S.objs[i].typ))
    return np.array(X), np.array(Y, np.float32), np.array(T)

if __name__ == '__main__':
    name, n_total, seed0 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    types = sys.argv[4].split(',') if len(sys.argv) > 4 else None
    jobs = [(seed0 + j, n_total // 8, types) for j in range(8)]
    with Pool(2) as p: R = p.map(work, jobs)
    X = np.concatenate([r[0] for r in R]); Y = np.concatenate([r[1] for r in R]); T = np.concatenate([r[2] for r in R])
    np.savez_compressed(f'data_{name}.npz', X=X, Y=Y, T=T)
    print(name, X.shape, Y.mean(), (Y > .5).mean())
