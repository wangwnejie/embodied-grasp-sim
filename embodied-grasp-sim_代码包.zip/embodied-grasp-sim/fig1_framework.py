import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
plt.rcParams.update({'font.sans-serif':['Noto Sans CJK SC'],'axes.unicode_minus':False,'savefig.dpi':600})
CM=1/2.54; K='black'
fig,ax=plt.subplots(figsize=(15.5*CM,6.6*CM)); ax.set_xlim(0,155); ax.set_ylim(-7,66); ax.axis('off')
def box(x,y,w,h,t,fc='white',fs=7.2,b=False):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.25,rounding_size=1',fc=fc,ec=K,lw=0.9))
    ax.text(x+w/2,y+h/2,t,ha='center',va='center',fontsize=fs,linespacing=1.3,fontweight='bold' if b else 'normal')
def arr(x1,y1,x2,y2,t=None,dx=0,dy=1.8,ls='-'):
    ax.annotate('',xy=(x2,y2),xytext=(x1,y1),arrowprops=dict(arrowstyle='-|>',color=K,lw=0.9,mutation_scale=8,linestyle=ls))
    if t: ax.text((x1+x2)/2+dx,(y1+y2)/2+dy,t,ha='center',va='bottom',fontsize=6.3)
# layer frames
for x,t in [(2,'感知层'),(41,'认知决策层'),(98,'执行层')]:
    pass
box(2,40,30,18,'深度相机\n桌面场景高度图\n实例掩码',fs=7)
box(2,10,30,18,'自然语言指令\n“先把所有轴承放入\n1号料箱……”',fs=7)
box(41,44,34,16,'零件识别\n形状—高度特征\n随机森林分类',fs=6.8)
box(41,26,34,14,'支撑关系推理\n堆叠/遮挡依赖',fs=6.8)
box(41,4,34,17,'指令语义解析\n目标三元组\n（类型，数量，料箱）',fs=6.8)
box(82,32,30,27,'依赖感知任务规划\n·拆除覆盖件\n·移开拥挤件\n·按指令顺序取放',fc='#e6e6e6',fs=6.6)
box(82,6,30,20,'抓取质量网络\n候选位姿质量评分\n选取最优位姿',fc='#e6e6e6',fs=6.8)
box(121,30,31,22,'工业机器人\n平行夹爪执行\n抓取—转运—放置',fs=7)
box(121,4,31,18,'交互经验池\n结果自监督标注\n在线校准评分',fs=6.8)
arr(32,51,41,52); arr(32,46,41,34); arr(32,19,41,13)
arr(75,52,82,50); arr(75,33,82,42); arr(75,13,82,36)
arr(97,32,97,26,'目标零件',dx=-7.5,dy=-1)
arr(112,20,121,36); ax.text(118.5,25.5,'抓取\n位姿',ha='left',va='center',fontsize=6.3)
arr(136.5,30,136.5,22,'成功/失败',dx=7,dy=-1)
arr(121,11,112,11); ax.text(116.5,12,'更新',ha='center',va='bottom',fontsize=6.3)
# closed loop back to perception
ax.plot([136.5,136.5],[52.6,63.5],color=K,lw=0.9,ls='--'); ax.plot([17,136.5],[63.5,63.5],color=K,lw=0.9,ls='--')
ax.annotate('',xy=(17,58.4),xytext=(17,63.5),arrowprops=dict(arrowstyle='-|>',color=K,lw=0.9,mutation_scale=8))
ax.text(77,64.2,'执行后重新观测（失败重抓、动态重规划）',ha='center',va='bottom',fontsize=6.6)
[ax.text(x,-4.5,s,ha='center',va='center',fontsize=7.4,fontweight='bold') for x,s in [(17,'感知层'),(77,'认知决策层'),(136.5,'执行层')]]
for xx in (36.5,116.5): ax.plot([xx,xx],[-6,60],color='#888888',lw=0.6,ls=':')
plt.savefig('h1.png',bbox_inches='tight',pad_inches=0.03); print('ok')
