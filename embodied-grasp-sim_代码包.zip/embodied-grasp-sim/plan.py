"""instruction parsing and dependency-aware task planning."""
import re, numpy as np

LEX = {'nut': ['六角螺母', '螺母'], 'bearing': ['滚动轴承', '轴承'], 'gear': ['齿轮'], 'block': ['垫块', '方块'],
       'bracket': ['L形支架', '角支架', '支架'], 'bolt': ['螺栓', '螺丝'], 'shaft': ['传动轴', '销轴', '轴']}
NUM = {'一': 1, '两': 2, '二': 2, '三': 3, '四': 4, '五': 5}
BIN = {'1': 1, '一': 1, '2': 2, '二': 2, '3': 3, '三': 3}


def parse(text):
    """'先把所有轴承放入1号料箱，再将两个螺母放到2号料盒' -> [(type, count or 'all', bin), ...] in order."""
    clauses = [c for c in re.split(r'[，,；;。]|然后|接着|随后|最后', text) if c.strip()]
    goals = []
    for c in clauses:
        typ = None
        for t, words in LEX.items():
            for w in words:
                if w in c:
                    typ = t; break
            if typ: break
        if typ is None: continue
        m = re.search(r'(\d|[一二三])\s*号', c)
        b = BIN[m.group(1)] if m else 1
        q = 'all'
        m2 = re.search(r'(\d+|[一两二三四五])\s*[个件只根块]', c)
        if m2 and not re.search(r'所有|全部|每', c):
            q = int(m2.group(1)) if m2.group(1).isdigit() else NUM[m2.group(1)]
        goals.append((typ, q, b))
    return goals


TEMPL = ['先把{q1}{t1}放入{b1}号料箱，再将{q2}{t2}放到{b2}号料盒',
         '请将{q1}{t1}分拣到{b1}号料箱；然后把{q2}{t2}放进{b2}号料箱',
         '首先取出{q1}{t1}放到{b1}号工位，接着把{q2}{t2}送入{b2}号料箱，最后将{q3}{t3}放入{b3}号料箱',
         '把{q1}{t1}放入{b1}号料盒，随后把{q2}{t2}放入{b2}号料盒']


def make_instruction(rng, goals):
    """render goals [(type,q,bin)] into a Chinese instruction using random synonyms/templates."""
    n = len(goals)
    tps = [t for t in TEMPL if t.count('{t') == n] or TEMPL[:1]
    tpl = tps[rng.integers(len(tps))]
    kw = {}
    for k, (t, q, b) in enumerate(goals, 1):
        words = LEX[t]; kw[f't{k}'] = words[rng.integers(len(words))]
        if q == 'all': kw[f'q{k}'] = ['所有', '全部的', '全部'][rng.integers(3)]
        else: kw[f'q{k}'] = (['', '一', '两', '三', '四', '五'][q] if rng.random() < .5 else str(q)) + ['个', '件'][rng.integers(2)]
        kw[f'b{k}'] = str(b) if rng.random() < .6 else '一二三'[b - 1]
    return tpl.format(**kw)
