import numpy as np, pickle, json, copy, time, sys, collections
from multiprocessing import Pool
from sim import *
from grasp import *
from perceive import infer_support

MODEL = pickle.load(open('model_main.pkl', 'rb'))
POL = {'random': pol_random, 'pca': pol_pca, 'antipodal': pol_antipodal, 'learned': pol_learned}
PS, AS = 2.0, np.radians(3)


def attempt_loop(S, i, meth, rng, max_try=3, sig=1.0, ps=PS, as_=AS, n=64):
    """closed loop grasping of target i. returns list of (success, reason) per attempt."""
    out = []; tabu = []
    for k in range(max_try):
        Hn, masks = S.observe(rng, sig=sig)
        if i not in masks: out.append((False, 'invisible')); break
        m = masks[i]
        if meth == 'learned': g = pol_learned(Hn, m, rng, model=MODEL, n=n, tabu=tabu)
        else: g = POL[meth](Hn, m, rng)
        ok, info = evaluate(S, i, g, rng, ps, as_)
        out.append((ok, info['reason']))
        if ok: break
        tabu.append(g); S.perturb(i, rng, 2.0)
    return out


def e1_scene(seed):
    rng = np.random.default_rng(seed)
    S0 = Scene(rng, int(rng.integers(10, 15)), n_stack=int(rng.integers(0, 3)))
    cand = [i for i in range(len(S0.objs)) if not S0.above(i) and S0.objs[i].M.sum() > 20]
    _, ID = S0.topid()
    cand = [i for i in cand if (ID == i).sum() > 20]
    tg = list(rng.choice(cand, min(4, len(cand)), replace=False))
    rows = []
    for i in tg:
        for meth in POL:
            S = copy.deepcopy(S0); r = np.random.default_rng(seed * 100 + int(i))
            res = attempt_loop(S, int(i), meth, r)
            rows.append(dict(meth=meth, typ=S0.objs[i].typ, first=res[0][0], reason=res[0][1], within=[any(x[0] for x in res[:k + 1]) for k in range(3)],
                             n_try=len(res), stacked=S0.objs[i].base > 0))
    return rows


def e3_scene(args):
    seed, sig, ps = args
    rng = np.random.default_rng(seed)
    S0 = Scene(rng, int(rng.integers(10, 15)), n_stack=int(rng.integers(0, 3)))
    _, ID = S0.topid()
    cand = [i for i in range(len(S0.objs)) if not S0.above(i) and (ID == i).sum() > 20]
    tg = list(rng.choice(cand, min(3, len(cand)), replace=False))
    rows = []
    for i in tg:
        for meth in ['pca', 'antipodal', 'learned']:
            S = copy.deepcopy(S0); r = np.random.default_rng(seed * 100 + int(i))
            res = attempt_loop(S, int(i), meth, r, max_try=1, sig=sig, ps=ps)
            rows.append(dict(meth=meth, sig=sig, ps=ps, ok=res[0][0]))
    return rows


def e2_scene(args):
    seed, mode = args
    rng = np.random.default_rng(seed)
    S0 = Scene(rng, 12, n_stack=2)
    out = {}
    for meth, order in mode:
        S = copy.deepcopy(S0); r = np.random.default_rng(seed + 7)
        n0 = len(S.objs); budget = 2 * n0; tries = 0; removed = 0; fails = collections.Counter()
        while tries < budget and removed < n0:
            Hn, masks = S.observe(r)
            masks = {i: m for i, m in masks.items() if m.sum() > 15}
            if not masks: break
            if order == 'q':
                on = infer_support(Hn, masks)
                best = None
                for i, m in masks.items():
                    if i in on.values(): continue        # perceived as supporting another part -> later
                    g, q = pol_learned(Hn, m, r, model=MODEL, n=32, return_q=True)
                    if best is None or q > best[0]: best = (q, i, g)
                if best is None:
                    i = list(masks)[0]; g = pol_learned(Hn, masks[i], r, model=MODEL, n=32)
                else: _, i, g = best
            else:
                i = list(masks)[r.integers(len(masks))]
                g = pol_learned(Hn, masks[i], r, model=MODEL) if meth == 'learned' else POL[meth](Hn, masks[i], r)
            ok, info = evaluate(S, i, g, r, PS, AS); tries += 1
            if ok: S.remove(i, r); removed += 1
            else:
                fails[info['reason']] += 1; S.perturb(i, r, 2.0)
                if info['reason'] == 'covered':
                    for j in S.above(i): S.perturb(j, r, 3.0)
        out[f'{meth}-{order}'] = dict(n=n0, removed=removed, tries=tries, fails=dict(fails))
    return out


if __name__ == '__main__':
    which = sys.argv[1]
    t0 = time.time()
    with Pool(2) as p:
        if which == 'e1':
            R = sum(p.map(e1_scene, range(9000, 9300)), [])
            json.dump(R, open('res_e1.json', 'w'))
        elif which == 'e3':
            jobs = [(s, sig, 2.0) for sig in [0.5, 1, 2, 3, 4] for s in range(9500, 9620)] + \
                   [(s, 1.0, ps) for ps in [1, 2, 4, 6] for s in range(9700, 9820)]
            R = sum(p.map(e3_scene, jobs), [])
            json.dump(R, open('res_e3.json', 'w'))
        elif which == 'e2':
            mode = [('random', 'rand'), ('pca', 'rand'), ('antipodal', 'rand'), ('learned', 'rand'), ('learned', 'q')]
            R = p.map(e2_scene, [(s, mode) for s in range(9900, 10000)])
            json.dump(R, open('res_e2.json', 'w'))
    print(which, 'done', time.time() - t0)
