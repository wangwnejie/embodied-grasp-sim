"""2.5D tabletop simulator for top-down parallel-jaw grasping of industrial parts.
Units: mm. Grid resolution RES mm/pixel. Height map = object top height above table.
"""
import numpy as np, cv2
from scipy import ndimage

RES = 2.0          # mm per pixel
N = 160            # grid size -> 320 mm workspace
G = dict(max_open=80.0, fw=10.0, ft=6.0, min_clear=2.0, depth=10.0,
         mu=0.5, F=15.0, r_eff=3.0, dyn=2.0, rho=7.85e-3)   # rho g/mm^3 (steel)
TYPES = ['nut', 'bearing', 'gear', 'block', 'bracket', 'bolt', 'shaft']
CN = {'nut': '六角螺母', 'bearing': '轴承', 'gear': '齿轮', 'block': '方块', 'bracket': 'L形支架',
      'bolt': '螺栓', 'shaft': '轴'}

xs = (np.arange(N) + 0.5) * RES
XX, YY = np.meshgrid(xs, xs)   # XX[r,c]=x of col c, YY[r,c]=y of row r


class Obj:
    def __init__(self, typ, rng, cx, cy, th):
        self.typ, self.cx, self.cy, self.th = typ, cx, cy, th
        r = rng
        if typ == 'nut':
            self.p = dict(a=r.uniform(8, 12)); self.p['h'] = r.uniform(7, 10); self.ext = self.p['a'] * 1.2
        elif typ == 'bearing':
            self.p = dict(R=r.uniform(11, 17)); self.p['h'] = r.uniform(8, 12); self.ext = self.p['R']
        elif typ == 'gear':
            self.p = dict(R=r.uniform(15, 22), n=int(r.integers(12, 20))); self.p['h'] = r.uniform(6, 9); self.ext = self.p['R'] + 3
        elif typ == 'block':
            self.p = dict(L=r.uniform(25, 45), W=r.uniform(16, 30)); self.p['h'] = r.uniform(15, 28)
            self.ext = np.hypot(self.p['L'], self.p['W']) / 2
        elif typ == 'bracket':
            self.p = dict(L1=r.uniform(36, 50), L2=r.uniform(26, 36), t=r.uniform(10, 14)); self.p['h'] = r.uniform(3, 5)
            self.ext = np.hypot(self.p['L1'], self.p['L2']) * 0.75
        elif typ == 'bolt':
            d = r.uniform(8, 12); self.p = dict(d=d, L=r.uniform(35, 55)); self.p['h'] = 1.5 * d
            self.ext = (self.p['L'] + 0.7 * d) / 2 + 2
        elif typ == 'shaft':
            d = r.uniform(10, 16); self.p = dict(d=d, L=r.uniform(40, 70)); self.p['h'] = d; self.ext = self.p['L'] / 2 + 1
        self.base = 0.0

    def local(self, X, Y):
        c, s = np.cos(self.th), np.sin(self.th)
        dx, dy = X - self.cx, Y - self.cy
        return c * dx + s * dy, -s * dx + c * dy

    def profile(self, X, Y):
        """return membership mask and thickness (height above own base)."""
        u, v = self.local(X, Y); p = self.p; t = self.typ
        if t == 'nut':
            a = p['a']; m = np.ones_like(u, bool)
            for k in range(3):
                ang = k * np.pi / 3; m &= np.abs(u * np.cos(ang) + v * np.sin(ang)) <= a
            m &= (u ** 2 + v ** 2) > (0.55 * a) ** 2
            return m, np.where(m, p['h'], 0.0)
        if t == 'bearing':
            rr = u ** 2 + v ** 2; m = (rr <= p['R'] ** 2) & (rr > (0.55 * p['R']) ** 2)
            return m, np.where(m, p['h'], 0.0)
        if t == 'gear':
            rho = np.hypot(u, v); phi = np.arctan2(v, u)
            m = (rho <= p['R'] - 2.5 + 5.0 * (np.cos(p['n'] * phi) > 0.2)) & (rho > 0.3 * p['R'])
            return m, np.where(m, p['h'], 0.0)
        if t == 'block':
            m = (np.abs(u) <= p['L'] / 2) & (np.abs(v) <= p['W'] / 2)
            return m, np.where(m, p['h'], 0.0)
        if t == 'bracket':
            L1, L2, tt = p['L1'], p['L2'], p['t']
            uu, vv = u + L1 / 3, v + L2 / 3
            m = ((uu >= 0) & (uu <= L1) & (vv >= 0) & (vv <= tt)) | ((uu >= 0) & (uu <= tt) & (vv >= 0) & (vv <= L2))
            return m, np.where(m, p['h'], 0.0)
        if t == 'bolt':
            d, L = p['d'], p['L']; r = d / 2
            u0 = u + (L + 0.7 * d) / 2 - 0.7 * d   # shaft from 0..L, head from -0.7d..0
            shaft = (u0 >= 0) & (u0 <= L) & (np.abs(v) <= r)
            head = (u0 < 0) & (u0 >= -0.7 * d) & (np.abs(v) <= 0.8 * d)
            hs = np.where(shaft, r + np.sqrt(np.clip(r ** 2 - v ** 2, 0, None)), 0.0)
            hh = np.where(head, 1.5 * d, 0.0)
            m = shaft | head
            return m, np.maximum(hs, hh)
        if t == 'shaft':
            d, L = p['d'], p['L']; r = d / 2
            m = (np.abs(u) <= L / 2) & (np.abs(v) <= r)
            return m, np.where(m, r + np.sqrt(np.clip(r ** 2 - v ** 2, 0, None)), 0.0)

    def bbox(self):
        e = self.ext + 2 * RES
        c0, c1 = int(max(0, (self.cx - e) / RES)), int(min(N, (self.cx + e) / RES + 1))
        r0, r1 = int(max(0, (self.cy - e) / RES)), int(min(N, (self.cy + e) / RES + 1))
        return r0, r1, c0, c1

    def raster(self):
        r0, r1, c0, c1 = self.bbox()
        m, th = self.profile(XX[r0:r1, c0:c1], YY[r0:r1, c0:c1])
        M = np.zeros((N, N), bool); T = np.zeros((N, N))
        M[r0:r1, c0:c1] = m; T[r0:r1, c0:c1] = th
        self.M, self.T = M, T
        w = T[M]; area = RES * RES
        self.vol = w.sum() * area
        self.mass = self.vol * G['rho'] / 1000.0  # kg
        self.com = np.array([(XX[M] * w).sum() / w.sum(), (YY[M] * w).sum() / w.sum()])
        return self


class Scene:
    def __init__(self, rng, n_obj=8, types=None, stack_p=0.0, margin=30, n_stack=0):
        self.rng = rng; self.objs = []
        types = types or TYPES
        tries = 0
        while len(self.objs) < n_obj and tries < 400:
            tries += 1
            typ = types[rng.integers(len(types))]
            o = Obj(typ, rng, rng.uniform(margin, N * RES - margin), rng.uniform(margin, N * RES - margin), rng.uniform(0, np.pi))
            o.raster()
            if o.M.sum() < 20: continue
            H = self.height()
            under = H[o.M]
            ov = (under > 0.5).mean()
            if ov > 0:
                if rng.random() > stack_p or ov < 0.5:  # either clear placement or a real stack
                    continue
                # do not stack on tall/thin unstable supports: require support covered >=50% and max 2 levels
                if any(b.base > 0 for b in self.objs if (b.M & o.M).any()): continue
                o.base = float(np.percentile(under[under > 0.5], 90))
            self.objs.append(o)
        self.alive = [True] * len(self.objs)
        for _ in range(n_stack):
            self.add_stack(rng, types)

    def add_stack(self, rng, types=None):
        """place a small part on top of a part with a flat top (block/gear/bearing/bracket)."""
        sup = [i for i, o in enumerate(self.objs) if self.alive[i] and o.base == 0 and o.typ in ('block', 'gear', 'bearing', 'bracket', 'shaft')
               and not self.above(i)]
        if not sup: return False
        i = sup[rng.integers(len(sup))]; s = self.objs[i]
        small = [t for t in (types or TYPES) if t in ('nut', 'bolt', 'bracket', 'shaft', 'bearing', 'gear')]
        for _ in range(20):
            typ = small[rng.integers(len(small))]
            o = Obj(typ, rng, s.com[0] + rng.normal(0, 4), s.com[1] + rng.normal(0, 4), rng.uniform(0, np.pi)); o.raster()
            H = self.height(); under = H[o.M]
            if o.M.sum() < 20 or (under > 0.5).mean() < 0.75: continue
            # must not touch a third object at the same level
            if any(j != i and self.alive[j] and (b.M & o.M).any() for j, b in enumerate(self.objs)): continue
            o.base = float(np.percentile(under[under > 0.5], 90))
            self.objs.append(o); self.alive.append(True); return True
        return False

    def height(self, exclude=None):
        H = np.zeros((N, N));
        for i, o in sorted(enumerate(self.objs), key=lambda t: t[1].base):
            if not getattr(self, 'alive', [True] * len(self.objs))[i] or i == exclude: continue
            top = np.where(o.M, o.base + o.T, 0.0)
            H = np.maximum(H, top)
        return H

    def topid(self):
        H = np.zeros((N, N)); ID = -np.ones((N, N), int)
        for i, o in sorted(enumerate(self.objs), key=lambda t: t[1].base):
            if not self.alive[i]: continue
            top = np.where(o.M, o.base + o.T, -1.0)
            sel = top > H; H[sel] = top[sel]; ID[sel] = i
        return H, ID

    def above(self, i):
        """indices of alive objects resting on object i"""
        o = self.objs[i]
        return [j for j, b in enumerate(self.objs) if self.alive[j] and j != i and b.base > o.base + 0.5 and (b.M & o.M).any()]

    def remove(self, i, rng=None):
        self.alive[i] = False
        # objects resting on i settle down
        for j, b in enumerate(self.objs):
            if not self.alive[j] or b.base <= 0: continue
            H = self.height(exclude=j)
            under = H[b.M]
            nb = float(np.percentile(under[under > 0.5], 90)) if (under > 0.5).mean() > 0.3 else 0.0
            if nb < b.base - 0.5:
                if rng is not None:  # falling part shifts slightly
                    b.cx += rng.normal(0, 3); b.cy += rng.normal(0, 3); b.th += rng.normal(0, 0.15); b.raster()
                b.base = nb

    def perturb(self, i, rng, s=2.0):
        b = self.objs[i]; b.cx += rng.normal(0, s); b.cy += rng.normal(0, s); b.th += rng.normal(0, 0.05); b.raster()

    def observe(self, rng, sig=1.0, drop=0.01, mask_err=1):
        H, ID = self.topid()
        Hn = H + rng.normal(0, sig, H.shape)
        Hn[rng.random(H.shape) < drop] = 0.0
        Hn = np.clip(Hn, 0, None)
        masks = {}
        for i in range(len(self.objs)):
            if not self.alive[i]: continue
            m = ID == i
            if m.sum() == 0: continue
            if mask_err:
                k = rng.integers(-mask_err, mask_err + 1)
                if k > 0: m = ndimage.binary_dilation(m, iterations=int(k)) & (H > 0.5)
                elif k < 0:
                    m2 = ndimage.binary_erosion(m, iterations=int(-k)); m = m2 if m2.sum() > 5 else m
            masks[i] = m
        return Hn, masks


# --------------------------------------------------------------- grasp evaluation
def _footprint(cx, cy, ax, perp, s):
    """pixel coords of finger footprint centred at s along axis (ft along axis x fw across)."""
    a = np.linspace(-G['ft'] / 2, G['ft'] / 2, 3); b = np.linspace(-G['fw'] / 2, G['fw'] / 2, 5)
    A, B = np.meshgrid(a, b)
    px = cx + (s + A) * ax[0] + B * perp[0]; py = cy + (s + A) * ax[1] + B * perp[1]
    c = np.clip((px / RES).astype(int), 0, N - 1); r = np.clip((py / RES).astype(int), 0, N - 1)
    inside = (px >= 0) & (px < N * RES) & (py >= 0) & (py < N * RES)
    return r, c, inside


def occupancy_id(scene, r, c, z):
    """object id occupying pixel (r,c) at height z (top-most interval containing z)"""
    for i, o in enumerate(scene.objs):
        if scene.alive[i] and o.M[r, c] and o.base <= z <= o.base + o.T[r, c]:
            return i
    return -1


def evaluate(scene, target, g, rng=None, pos_sig=0.0, ang_sig=0.0, H=None, detail=False):
    """g=(cx,cy,theta,open). returns (success, info)."""
    cx, cy, th, op = g
    if rng is not None and (pos_sig > 0 or ang_sig > 0):
        cx += rng.normal(0, pos_sig); cy += rng.normal(0, pos_sig); th += rng.normal(0, ang_sig)
    if H is None: H = scene.height()
    ax = np.array([np.cos(th), np.sin(th)]); perp = np.array([-ax[1], ax[0]])
    rc, cc = int(np.clip(cy / RES, 0, N - 1)), int(np.clip(cx / RES, 0, N - 1))
    # grasp height: relative to the highest point under the gripper centre region along the axis
    top = H[rc, cc]
    # use target local top near centre if centre falls in a hole
    zt = top if top > 0.5 else 0.0
    if zt <= 0.5:
        # look along the axis within +-op/2 for the highest target surface
        ss = np.linspace(-op / 2, op / 2, 21)
        px = np.clip(((cx + ss * ax[0]) / RES).astype(int), 0, N - 1); py = np.clip(((cy + ss * ax[1]) / RES).astype(int), 0, N - 1)
        zt = H[py, px].max()
    # fingers descend until they reach the commanded depth or touch the surface below them (force/depth sensing)
    floor = 0.0
    for sgn in (-1, 1):
        r, c, ins = _footprint(cx, cy, ax, perp, sgn * op / 2)
        if ins.any(): floor = max(floor, H[r, c][ins].max())
    z = max(zt - G['depth'], floor + G['min_clear'], G['min_clear'])
    info = dict(reason='ok', z=z)
    if zt - z < 1.0:          # fingers stopped on neighbouring parts: not enough of the target left to grip
        info['reason'] = 'collision'; return False, info
    # closing: march each finger inward
    steps = np.arange(op / 2, 0, -RES / 2)
    contacts = []
    for sgn in (-1, 1):
        hit = None
        for s in steps:
            r, c, ins = _footprint(cx, cy, ax, perp, sgn * s)
            hm = (H[r, c] > z + 0.5) & ins
            if hm.any():
                hit = (s, r[hm], c[hm]); break
        if hit is None:
            info['reason'] = 'miss'; return False, info
        contacts.append(hit)
    s1, s2 = contacts[0][0], contacts[1][0]
    width = s1 + s2
    if width > G['max_open']:
        info['reason'] = 'width'; return False, info
    # object identity at contacts
    ids = []
    for (s, rr, cc2) in contacts:
        cand = [occupancy_id(scene, a, b, z + 0.5) for a, b in zip(rr, cc2)]
        cand = [x for x in cand if x >= 0]
        ids.append(max(set(cand), key=cand.count) if cand else -1)
    if ids[0] != ids[1] or ids[0] != target:
        info['reason'] = 'wrong'; info['ids'] = ids; return False, info
    o = scene.objs[target]
    # anything stacked above target that the fingers would also clamp? handled by occupancy; objects above make lifting unstable
    # antipodal check using 2D slice normals of target at height z
    sl = o.M & (o.base + o.T >= z + 0.5) & (o.base <= z + 0.5)
    sm = ndimage.gaussian_filter(sl.astype(float), 1.0)
    gy, gx = np.gradient(sm)
    ok = True; angs = []
    for k, (s, rr, cc2) in enumerate(contacts):
        nx, ny = -gx[rr, cc2].mean(), -gy[rr, cc2].mean()   # outward normal
        nn = np.hypot(nx, ny)
        if nn < 1e-6: ok = False; angs.append(90); continue
        nx, ny = nx / nn, ny / nn
        close_dir = -ax if k == 1 else ax   # finger at -s moves +ax ; at +s moves -ax
        # outward normal should oppose closing direction
        cosang = -(nx * close_dir[0] + ny * close_dir[1])
        ang = np.degrees(np.arccos(np.clip(cosang, -1, 1))); angs.append(ang)
        if ang > np.degrees(np.arctan(G['mu'])): ok = False
    info['angles'] = angs
    if not ok:
        info['reason'] = 'slip_normal'; return False, info
    # torque stability: COM distance to contact line
    p1 = np.array([cx, cy]) - s1 * ax; p2 = np.array([cx, cy]) + s2 * ax
    e1, e2 = p2 - p1, o.com - p1
    d = abs(e1[0] * e2[1] - e1[1] * e2[0]) / max(np.linalg.norm(p2 - p1), 1e-6)   # mm
    tau = G['dyn'] * o.mass * 9.81 * d / 1000.0
    cap = 2 * G['mu'] * G['F'] * G['r_eff'] / 1000.0
    info['d'] = d; info['tau'] = tau
    if tau > cap:
        info['reason'] = 'torque'; return False, info
    # objects resting on target: lifting them together is unstable
    if scene.above(target):
        info['reason'] = 'covered'; return False, info
    info['width'] = width
    return True, info


def robust_quality(scene, target, g, rng, k=8, pos_sig=2.0, ang_sig=np.radians(3), H=None):
    if H is None: H = scene.height()
    return np.mean([evaluate(scene, target, g, rng, pos_sig, ang_sig, H)[0] for _ in range(k)])
