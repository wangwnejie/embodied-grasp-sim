import numpy as np, pickle, sys, json, time
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import roc_auc_score, mean_absolute_error

name = sys.argv[1]
d = np.load(f'data_{name}.npz'); X, Y, T = d['X'], d['Y'], d['T']
rng = np.random.default_rng(0); idx = rng.permutation(len(X)); nt = int(.85 * len(X))
tr, te = idx[:nt], idx[nt:]
t0 = time.time()
m = MLPRegressor(hidden_layer_sizes=(256, 128), activation='relu', alpha=1e-4, batch_size=256, learning_rate_init=1e-3,
                 max_iter=80, early_stopping=True, validation_fraction=0.1, n_iter_no_change=5, random_state=0)
m.fit(X[tr], Y[tr])
p = m.predict(X[te])
res = dict(n=len(X), n_train=len(tr), epochs=m.n_iter_, mae=float(mean_absolute_error(Y[te], p)),
           auc=float(roc_auc_score(Y[te] > .5, p)), time=time.time() - t0, loss_curve=[float(x) for x in m.loss_curve_],
           val_curve=[float(x) for x in m.validation_scores_])
print(json.dumps({k: v for k, v in res.items() if 'curve' not in k}))
pickle.dump(m, open(f'model_{name}.pkl', 'wb')); json.dump(res, open(f'train_{name}.json', 'w'))
